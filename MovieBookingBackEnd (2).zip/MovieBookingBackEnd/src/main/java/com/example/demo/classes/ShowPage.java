package com.example.demo.classes;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.example.demo.modal.Movies;
import com.example.demo.modal.Theatre;

public class ShowPage 
{
	Movies movie;
	String theatreName;
	Date date;
	
	List<Date> times = new ArrayList<Date>();
	

}
