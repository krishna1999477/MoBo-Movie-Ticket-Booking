//ANUJ DATA FOR MOBO


CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
)


INSERT INTO `user` (`userid`, `email`, `phone`, `username`, `password`) VALUES
(1, 'SP@gmail.com', '9595218216', 'Sagar Patil', 'Sagar123');


CREATE TABLE `city` (
  `zipcode` int(11) NOT NULL,
  `cityname` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL
)

	
INSERT INTO `city` (`zipcode`, `cityname`, `state`) VALUES
(11096, 'Noida', ' Uttar Pradesh ');


CREATE TABLE `theatre` (
  `theatreid` int(11) NOT NULL,
  `theatrename` varchar(255) DEFAULT NULL,
  `totalscreens` int(11) DEFAULT NULL,
  `zipcode` int(11) DEFAULT NULL
)


INSERT INTO `theatre` (`theatreid`, `theatrename`, `totalscreens`, `zipcode`) VALUES
(1, 'Wave', 3, 110096);    // real name(5, 'Elita', 9, 11096)


CREATE TABLE `screen` (
  `screenid` int(11) NOT NULL,
  `screenname` varchar(255) DEFAULT NULL,
  `totalnoofseats` int(11) DEFAULT NULL,
  `theatreid` int(11) DEFAULT NULL
)

INSERT INTO `screen` (`screenid`, `screenname`, `totalnoofseats`, `theatreid`) VALUES
(1, 'Screen1', 40, 1),
(2, 'Screen2', 40, 1),
(3, 'Screen3', 60, 1);
--------------------------------

CREATE TABLE `movies` (
  `movieid` int(11) NOT NULL,
  `description` varchar(800) NOT NULL,
  `duration` time DEFAULT NULL,
  `image` varchar(500) DEFAULT NULL,
  `language` varchar(50) DEFAULT NULL,
  `rating` double DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `trailer` varchar(300) DEFAULT NULL,
  `type` varchar(200) DEFAULT NULL
)

INSERT INTO `movies` (`movieid`, `description`, `duration`, `image`, `language`, `rating`, `title`, `trailer`, `type`) VALUES
(1, 'The Devil Made Me Do It reveals a chilling story of terror, murder and unknown evil that shocked even experienced real-life paranormal investigators Ed and Lorraine Warren.', '01:46:56', 'https://i2.wp.com/moviesandmania.com/wp-content/uploads/2020/08/Conjuring-the-Devil-movie-film-horror-demon-nun-2020.jpg?resize=370%2C527&ssl=1', 'English', 8.8, 'The Conjuring: The Devil Made Me Do It', 'https://youtu.be/k10ETZ41q5o', 'Horror'),
(2, 'Set in 1984 during the Cold War, the film follows Diana and her past love Steve Trevor as they face off against Max Lord and Cheetah. Discussion of a sequel began shortly after the release of the first film in June 2017 and the decision to proceed was confirmed the following month.', '01:46:56', 'https://static3.srcdn.com/wordpress/wp-content/uploads/2020/12/Gal-Gadot-in-Wonder-Woman-1984-Poster.jpg', 'Hindi', 9.3, 'Wonder Woman 1984', 'https://www.youtube.com/watch?v=1Q8fG0TtVAY', 'Action'),
(3, 'This is based on a Gangster', '02:18:56', 'https://wallpapercave.com/wp/wp4019377.jpg', 'Hindi', 9.3, 'KGF', 'https://www.youtube.com/watch?v=-KfsY-qwBS0', 'Action');





-----------------------
CREATE TABLE `movieshow` (
  `showid` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `price` double DEFAULT NULL,
  `starttime` time DEFAULT NULL,
  `movieid` int(11) DEFAULT NULL,
  `screenid` int(11) DEFAULT NULL
);


INSERT INTO `movieshow` (`showid`, `date`, `price`, `starttime`, `movieid`, `screenid`) VALUES
(1, '2021-03-20', 190, '09:30:00', 1, 1),
(2, '2021-03-20', 260, '12:30:00', 1, 1),
(3, '2021-03-20', 260, '04:30:00', 1, 1),
(4, '2021-03-20', 175, '09:30:00', 2, 2),
(5, '2021-03-20', 200, '14:30:00', 2, 2),
(6, '2021-03-20', 200, '06:30:00', 2, 2),
(7, '2021-03-20', 280, '13:00:00', 3, 3),
(8, '2021-03-20', 290, '017:30:00', 3, 3);



-------------------------------------

CREATE TABLE `seat` (
  `seatid` int(11) NOT NULL,
  `isbooked` bit(1) DEFAULT NULL,
  `seatnumber` int(11) DEFAULT NULL,
  `showid` int(11) DEFAULT NULL,
  `screenid` int(11) DEFAULT NULL
);




INSERT INTO `seat` (`seatid`, `isbooked`, `seatnumber`, `showid`, `screenid`) VALUES
(1, b'0', 1, 1, 1),
(2, b'0', 2, 1, 1),
(3, b'0', 3, 1, 1),
(4, b'0', 4, 1, 1),
(5, b'0', 5, 1, 1),
(6, b'0', 6, 1, 1),
(7, b'0', 7, 1, 1),
(8, b'0', 8, 1, 1),
(9, b'0', 9, 1, 1),
(10, b'0', 10, 1, 1),
(11, b'0', 11, 1, 1),
(12, b'0', 12, 1, 1),
(13, b'0', 13, 1, 1),
(14, b'0', 14, 1, 1),
(15, b'0', 15, 1, 1),
(16, b'0', 16, 1, 1),
(17, b'0', 17, 1, 1),
(18, b'0', 18, 1, 1),
(19, b'0', 19, 1, 1),
(20, b'0', 20, 1, 1),
(21, b'0', 21, 1, 1),
(22, b'0', 22, 1, 1),
(23, b'0', 23, 1, 1),
(24, b'0', 24, 1, 1),
(25, b'0', 25, 1, 1),
(26, b'0', 26, 1, 1),
(27, b'0', 27, 1, 1),
(28, b'0', 28, 1, 1),
(29, b'0', 29, 1, 1),
(30, b'0', 30, 1, 1),
(31, b'0', 31, 1, 1),
(32, b'0', 32, 1, 1),
(33, b'0', 33, 1, 1),
(34, b'0', 34, 1, 1),
(35, b'0', 35, 1, 1),
(36, b'0', 36, 1, 1),
(37, b'0', 37, 1, 1),
(38, b'0', 38, 1, 1),
(39, b'0', 39, 1, 1),
(40, b'0', 40, 1, 1);
INSERT INTO `seat` (`seatid`, `isbooked`, `seatnumber`, `showid`, `screenid`) VALUES
(41, b'0', 41, 2, 2),
(42, b'0', 42, 2, 2),
(43, b'0', 43, 2, 2),
(44, b'0', 44, 2, 2),
(45, b'0', 45, 2, 2),
(46, b'0', 46, 2, 2),
(47, b'0', 47, 2, 2),
(48, b'0', 48, 2, 2),
(49, b'0', 49, 2, 2),
(50, b'0', 50, 2, 2),
(51, b'0', 51, 2, 2),
(52, b'0', 52, 2, 2),
(53, b'0', 53, 2, 2),
(54, b'0', 54, 2, 2),
(55, b'0', 55, 2, 2),
(56, b'0', 56, 2, 2),
(57, b'0', 57, 2, 2),
(58, b'0', 58, 2, 2),
(59, b'0', 59, 2, 2),
(60, b'0', 60, 2, 2),
(61, b'0', 61, 2, 2),
(62, b'0', 62, 2, 2),
(63, b'0', 63, 2, 2),
(64, b'0', 64, 2, 2),
(65, b'0', 65, 2, 2),
(66, b'0', 66, 2, 2),
(67, b'0', 67, 2, 2),
(68, b'0', 68, 2, 2),
(69, b'0', 69, 2, 2),
(70, b'0', 70, 2, 2),
(71, b'0', 71, 2, 2),
(72, b'0', 72, 2, 2),
(73, b'0', 73, 2, 2),
(74, b'0', 74, 2, 2),
(75, b'0', 75, 2, 2),
(76, b'0', 76, 2, 2),
(77, b'0', 77, 2, 2),
(78, b'0', 78, 2, 2),
(79, b'0', 79, 2, 2),
(80, b'0', 80, 2, 2);
INSERT INTO `seat` (`seatid`, `isbooked`, `seatnumber`, `showid`, `screenid`) VALUES
(81, b'0', 81, 3, 3),
(82, b'0', 82, 3, 3),
(83, b'0', 83, 3, 3),
(84, b'0', 84, 3, 3),
(85, b'0', 85, 3, 3),
(86, b'0', 86, 3, 3),
(87, b'0', 87, 3, 3),
(88, b'0', 88, 3, 3),
(89, b'0', 89, 3, 3),
(90, b'0', 90, 3, 3),
(91, b'0', 91, 3, 3),
(92, b'0', 92, 3, 3),
(93, b'0', 93, 3, 3),
(94, b'0', 94, 3, 3),
(95, b'0', 95, 3, 3),
(96, b'0', 96, 3, 3),
(97, b'0', 97, 3, 3),
(98, b'0', 98, 3, 3),
(99, b'0', 99, 3, 3),
(100, b'0', 100, 3, 3),
(101, b'0', 101, 3, 3),
(102, b'0', 102, 3, 3),
(103, b'0', 103, 3, 3),
(104, b'0', 104, 3, 3),
(105, b'0', 105, 3, 3),
(106, b'0', 106, 3, 3),
(107, b'0', 107, 3, 3),
(108, b'0', 108, 3, 3),
(109, b'0', 109, 3, 3),
(110, b'0', 110, 3, 3),
(111, b'0', 111, 3, 3),
(112, b'0', 112, 3, 3),
(113, b'0', 113, 3, 3),
(114, b'0', 114, 3, 3),
(115, b'0', 115, 3, 3),
(116, b'0', 116, 3, 3),
(117, b'0', 117, 3, 3),
(118, b'0', 118, 3, 3),
(119, b'0', 119, 3, 3),
(120, b'0', 120, 3, 3),
(121, b'0', 121, 3, 3),
(122, b'0', 122, 3, 3),
(123, b'0', 123, 3, 3),
(124, b'0', 124, 3, 3),
(125, b'0', 125, 3, 3),
(126, b'0', 126, 3, 3),
(127, b'0', 127, 3, 3),
(128, b'0', 128, 3, 3),
(129, b'0', 129, 3, 3),
(130, b'0', 130, 3, 3),
(131, b'0', 131, 3, 3),
(132, b'0', 132, 3, 3),
(133, b'0', 133, 3, 3),
(134, b'0', 134, 3, 3),
(135, b'0', 135, 3, 3),
(136, b'0', 136, 3, 3),
(137, b'0', 137, 3, 3),
(138, b'0', 138, 3, 3),
(139, b'0', 139, 3, 3),
(140, b'0', 140, 3, 3);





--
-- Indexes for dumped tables
--

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`zipcode`),
  ADD UNIQUE KEY `UK_bcw53ef4lj0a72h76uo9opq40` (`cityname`);

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`movieid`);

--
-- Indexes for table `movieshow`
--
ALTER TABLE `movieshow`
  ADD PRIMARY KEY (`showid`),
  ADD KEY `FK6egiuvh90a7ayg62ickqm8b2p` (`movieid`),
  ADD KEY `FKcxvv8e6lpwq49y5e7nm9n71dn` (`screenid`);

--
-- Indexes for table `screen`
--
ALTER TABLE `screen`
  ADD PRIMARY KEY (`screenid`),
  ADD KEY `FKrm9rwdnvjc1tti5sqdkp3wg9d` (`theatreid`);

--
-- Indexes for table `seat`
--
ALTER TABLE `seat`
  ADD PRIMARY KEY (`seatid`),
  ADD KEY `FKc9t3tj182gbea7raruvxmoky7` (`showid`),
  ADD KEY `FKp4edtobp2b04ok9i0kjuut67b` (`screenid`);

--
-- Indexes for table `theatre`
--
ALTER TABLE `theatre`
  ADD PRIMARY KEY (`theatreid`),
  ADD KEY `FKey2kehjy3no75uu5ummckcxuu` (`zipcode`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `movieid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `movieshow`
--
ALTER TABLE `movieshow`
  MODIFY `showid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=563;

--
-- AUTO_INCREMENT for table `screen`
--
ALTER TABLE `screen`
  MODIFY `screenid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `seat`
--
ALTER TABLE `seat`
  MODIFY `seatid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27794;

--
-- AUTO_INCREMENT for table `theatre`
--
ALTER TABLE `theatre`
  MODIFY `theatreid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `movieshow`
--
ALTER TABLE `movieshow`
  ADD CONSTRAINT `FK6egiuvh90a7ayg62ickqm8b2p` FOREIGN KEY (`movieid`) REFERENCES `movies` (`movieid`),
  ADD CONSTRAINT `FKcxvv8e6lpwq49y5e7nm9n71dn` FOREIGN KEY (`screenid`) REFERENCES `screen` (`screenid`);

--
-- Constraints for table `screen`
--
ALTER TABLE `screen`
  ADD CONSTRAINT `FKrm9rwdnvjc1tti5sqdkp3wg9d` FOREIGN KEY (`theatreid`) REFERENCES `theatre` (`theatreid`);

--
-- Constraints for table `seat`
--
ALTER TABLE `seat`
  ADD CONSTRAINT `FKc9t3tj182gbea7raruvxmoky7` FOREIGN KEY (`showid`) REFERENCES `movieshow` (`showid`),
  ADD CONSTRAINT `FKp4edtobp2b04ok9i0kjuut67b` FOREIGN KEY (`screenid`) REFERENCES `screen` (`screenid`);

--
-- Constraints for table `theatre`
--
ALTER TABLE `theatre`
  ADD CONSTRAINT `FKey2kehjy3no75uu5ummckcxuu` FOREIGN KEY (`zipcode`) REFERENCES `city` (`zipcode`);
COMMIT;
